#!/usr/bin/env python
# -*- coding: utf-8 -*-

from definiciones import *
def habilitar_recomendacion():
    return False

def agregar_actor(datos):

    return

def eliminar_actor(idd):

    return



def sobreescribirpelicula(datos):

    return

def sobreescribiractor(datos):

    return


def sobreescribirusuario(datos):

    return


def buscar_id(nickname):

    return 0

def agregar_pelicula(datos):

    return

def eliminar_pelicula(idd):

    return

def verificar_password(password,ide):

    return False


def guardar_datos(datos):

    return

def verificar_ingreso(usuario, password):

    return False

def crear_relacion(datos):

    return

def votar_pelicula(idpelicula):

    return


def recomendar_pelicula():

    return

def obtener_actores(idpelicula):

    return

def obtener_peliculas(idactor):

    return

def buscar_peliculas(tag):

    return









