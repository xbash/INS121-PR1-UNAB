#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bottle import route, run, get, post, request, static_file, redirect
from funciones import *
from datetime import *

@route('/static/:path#.+#', name='static')
def static(path):
    return static_file(path, root='static')

# Si se escribe en el navegador http://localhost:8080/ o
# http://localhost:8080/tuiteos, entonces ejecuta esta funcion.
@route('/')
def index():
    a=open('peliculas.dat')
    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()
    if habilitar_recomendacion():
        datos=recomendar_pelicula()
        link=datos[8].split('=')[1]
        imagen='/static/img/'+datos[7]
        idpeli=datos[0]
        conjuntoactores=obtener_actores(idpeli)
        html_movie = '<div>La pelicula recomendada es</div>\n'
        html_movie+="<table id='fichapelicula'>\n"
        html_movie += "<tr>\n"
        html_movie += "<td><img src="+imagen+" width='320' height='466'></td>\n"
        html_movie += "<td>\n"
        html_movie += "<div>Nombre: <br>-"+datos[1]+"</div>\n"
        html_movie += "<div>Director: <br>-"+datos[2]+"</div>\n"
        html_movie += "<div>Pais:<br>-"+datos[3]+"</div>\n"
        html_movie += "<div id='actores'>actores:\n"
        for actor in conjuntoactores:
            html_movie += "<div>-"+actor+"</div>\n"
        html_movie += "</div>\n"
        html_movie += "</td>\n"
        html_movie += "</tr>\n"
        html_movie+="</table>\n" 
        html_movie += "<iframe id='trailer'  width='640' height='390' src=//www.youtube.com/embed/"+link+" frameborder='0' allowfullscreen>\n"
        html_movie += "</iframe>\n"

    archivo = open("static/login.html")
    html = archivo.read()
    
    if habilitar_recomendacion():
        html=   html.replace("<!--PELICULAS-->", html_lista)
        html = html.replace("<!--RECOMENDADA-->", html_movie)

    archivo.close()
    return html
@route ('/votar', method='POST')
def votar():
    idvoto=request.forms.get("listapelicula")
    votar_pelicula(idvoto)
    redirect ('/')


@route('/:usuario')
def menu_principal(usuario):
    archivo = open("static/Usuario.html")
    html = archivo.read()
    html = html.replace("<!--USUARIO-->", usuario)
    archivo.close()
    return html

@route('/cerrarsesion',method="POST")
def cerrarsesion():
    archivo = open("static/login.html")
    html = archivo.read()
    archivo.close()
    return html

@route('/error')
def error_login():
    archivo = open("static/login.html")
    html = archivo.read()
    html = html.replace("<!--MENSAJE-->", "Usuario y/o password incorrectos. Vuelva a intentarlo.")
    archivo.close()
    return html

@route('/login', method='POST')
def login():
    usuario = request.forms.get("usuario")
    password = request.forms.get("password")

    if verificar_ingreso(usuario, password):
        redirect('/' + usuario)
    else:
        redirect('/error')


@route ('/editarusuario')
def editarusuario():
    archivo = open("static/perfil.html")
    html = archivo.read()
    archivo.close()
    return html

@route('/registro', method="POST")
def registro():
    archivo = open("static/registroexitoso.html")
    html = archivo.read()
    archivo.close()
    if request.forms.get('password')==request.forms.get('password2'):

        datos = {
        "nombre": request.forms.get('usuario'),
        "nickname": request.forms.get('nickname'),
        "edad": request.forms.get('edad'),
        "pais": request.forms.get('pais'),
        "contrasenna": request.forms.get('password'),
        }
        guardar_datos(datos)
        html = html.replace("<!--USERNAME-->", datos['nickname'])

        return html
    else:
        archivo2=open("static/login.html")
        html2=archivo2.read()
        archivo2.close()
        return html2

@route('/accioneditarusuario', method='POST')
def accioneditarusuario():
    archivo = open("static/registroexitoso.html")
    html = archivo.read()
    archivo.close()


    usuario = request.forms.get("usuario")
    nickname = request.forms.get("nickname")
    nicknamenuevo = request.forms.get("nicknamenuevo")
    edad = request.forms.get("edad")
    pais = request.forms.get("pais")
    password = request.forms.get("password")
    passwordnueva = request.forms.get("password2")
    passwordnueva2 = request.forms.get("password3")
    ide=buscar_id(nickname)
    datos=dict()
    datos["id"]=ide
    datos[ "nombre"]=usuario
    datos["nickname"]= nicknamenuevo
    datos["edad"]= edad
    datos["pais"]= pais
    datos["contrasenna"]= passwordnueva


    if ide!=0:
        if verificar_password(password,ide):
            if passwordnueva==passwordnueva2:
                sobreescribirusuario(datos)



                return html



    archivo2=open("static/login.html")
    html2=archivo2.read()
    archivo2.close()
    return html2

#annadir actor
@route('/annadiractor')
def annadiractor():
    archivo = open("static/annadiractor.html")
    html = archivo.read()
    archivo.close()
    return html

@route('/accionagregaractor',method='POST')
def agregaractor():
    archivo = open("static/actorexitoso.html")
    html = archivo.read()
    archivo.close()

    nombre=request.forms.get("nombre")
    fechadenacimiento=request.forms.get("fechadenacimiento")
    lugar=request.forms.get("lugardenacimiento")
    imagen=request.forms.get("imagen")



    datos = {
        "nombre": nombre,
        "fechadenacimiento": fechadenacimiento,
        "lugar": lugar,
        "imagen": imagen,

        }
    agregar_actor(datos)
    return html

@route ('/editaractor')
def editaractor():
    a=open('actores.dat')

    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]

        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()


    archivo = open("static/editaractor.html")
    html = archivo.read()
    html = html.replace("<!--ACTORES-->", html_lista)
    archivo.close()
    return html

@route ('/accioneditaractor', method='POST')
def accioneditaractor():
    archivo = open("static/edicionactorexitosa.html")
    html = archivo.read()
    archivo.close()


    idd = request.forms.get("lista")
    new_name = request.forms.get("nombrenuevo")
    fechanacimiento = request.forms.get("fechadenacimiento")
    lugarnacimiento = request.forms.get("lugardenacimiento")
    imagen = request.forms.get("imagen")


    

    datos=dict()
    datos["id"]=idd
    datos["nombre"]=new_name
    datos["fechanacimiento"]= fechanacimiento
    datos["lugarnacimiento"]= lugarnacimiento    
    datos["imagen"]= imagen

    sobreescribiractor(datos)
    return html

@route('/eliminaractor')
def eliminaractor(): 
    a=open('actores.dat')

    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        id_actor=linea.strip().split(';')[0]
        html_lista+="<option value="+id_actor+">"+nombre+"</option>\n"
    a.close()


    archivo = open("static/eliminaractor.html")
    html = archivo.read()
    html = html.replace("<!--LISTA-->", html_lista)
    archivo.close()

    return html

@route ('/accioneliminaractor', method='POST')
def eliminaractorr():
    archivo = open("static/eliminacionactorexitosa.html")
    html = archivo.read()
    archivo.close()


    idd = request.forms.get("lista")

    eliminar_actor(idd)
    return html

#annadir pelicula
@route('/annadirpelicula')
def annadirpelicula():
    archivo = open("static/annadirpelicula.html")
    html = archivo.read()
    archivo.close()
    return html

@route('/accionagregarpelicula',method='POST')
def agregarpelicula():
    archivo = open("static/peliculaexitosa.html")
    html = archivo.read()
    archivo.close()

    nombre=request.forms.get("nombre")
    duracion=request.forms.get("duracion")
    fecha_estreno=request.forms.get("estreno")
    director=request.forms.get("director")
    genero=request.forms.get("genero")
    pais=request.forms.get("pais")
    imagen=request.forms.get("imagen")
    trailer=request.forms.get("trailer")
    tags=request.forms.get("tags")


    datos = {
        "nombre": nombre,
        "duracion": duracion,
        "estreno": fecha_estreno,
        "pais": pais,
        "genero": genero,
        "director": director,
        "imagen": imagen,
        "trailer": trailer,
        "tags": tags,

        }
    agregar_pelicula(datos)
    
    return html

@route ('/editarpelicula')
def editarpelicula():
    a=open('peliculas.dat')

    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()

    archivo = open("static/editarpelicula.html")
    html = archivo.read()
    html = html.replace("<!--PELICULAS-->", html_lista)
    archivo.close()
    return html

@route('/accioneditarpelicula', method='POST')
def accioneditarpelicula():
    archivo = open("static/edicionexitosa.html")
    html = archivo.read()
    archivo.close()


    idd = request.forms.get("lista")
    new_name = request.forms.get("nombrenuevo")
    duracion = request.forms.get("duracion")
    fechaestreno = request.forms.get("estreno")
    director = request.forms.get("director")
    genero = request.forms.get("genero")
    pais = request.forms.get("pais")
    imagen = request.forms.get("imagen")
    trailer = request.forms.get("trailer")
    tags = request.forms.get("tags")

    

    datos=dict()
    datos["id"]=idd
    datos["nombre"]=new_name
    datos["director"]= director
    datos["pais"]= pais
    datos["fechaestreno"]= fechaestreno
    datos["genero"]= genero
    datos["duracion"]= duracion
    datos["imagen"]= imagen
    datos["trailer"]= trailer
    datos["tags"]=tags

    sobreescribirpelicula(datos)
    return html

@route ('/eliminarpelicula')
def eliminarpelicula():

    a=open('peliculas.dat')

    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()


    archivo = open("static/eliminarpelicula.html")
    html = archivo.read()
    html = html.replace("<!--LISTA-->", html_lista)
    archivo.close()

    return html

@route ('/accioneliminarpelicula', method='POST')
def eliminarmovie():
    archivo = open("static/eliminacionexitosa.html")
    html = archivo.read()
    archivo.close()


    idd= request.forms.get("lista")

    eliminar_pelicula(idd)
    return html

#Buscadores

@route('/buscaractor',method='POST')
def buscaractor():
    a=open('peliculas.dat')
    html_lista=''
    aux=True
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()

    nombre = request.forms.get("actor")
    a=open('actores.dat')
    for linea in a:
        name=linea.strip().split(';')[1]

        datos=linea.strip().split(';')
        if name==nombre:
            aux=False
            idactor=datos[0]
            conjuntopeliculas=obtener_peliculas(idactor)
            imagen='static/img/'+datos[4]


            html_actor = ''
            html_actor+="<table id='fichapelicula'>\n"
            html_actor += "<tr>\n"
            html_actor += "<td><img src="+imagen+" width='320' height='466'></td>\n"
            html_actor += "<td>\n"
            html_actor += "<div>Nombre: <br>- "+datos[1]+"</div>\n"
            html_actor += "<div>Fecha de nacimiento: <br>- "+datos[2]+"</div>\n"
            html_actor += "<div>Lugar de nacimiento: <br>- "+datos[3]+"</div>\n"
            html_actor += "<div id='actores'>Peliculas:<br>\n"
            for peli in conjuntopeliculas:
                html_actor += "- "+    peli+"<br>\n"
            html_actor += "</div>\n"
            html_actor += "</td>\n"
            html_actor += "</tr>\n"
            html_actor+="</table>\n"
    if aux:
        redirect('/ups')


    archivo = open("static/login.html")
    html = archivo.read()
    html = html.replace("<!--ACTOR-->", html_actor)
    html=   html.replace("<!--PELICULAS-->", html_lista)

    return html

@route('/buscarpelicula',method='POST')
def buscarpelicula():
    aux=True

    a=open('peliculas.dat')
    html_lista=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_lista+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()


    tag = request.forms.get("pelicula")
    conjuntopelis=buscar_peliculas(tag)
    html_movie = '<div></div>\n'
    for nombre in conjuntopelis:
        a=open('peliculas.dat')

        for linea in a:
            name=linea.strip().split(';')[1]
            datos=linea.strip().split(';')
            if name==nombre:
                aux=False
                idpeli=datos[0]
                conjuntoactores=obtener_actores(idpeli)
                link=datos[8].split('=')[1]
                imagen='/static/img/'+datos[7]


                
                html_movie+="<table id='fichapelicula'>\n"
                html_movie += "<tr>\n"
                html_movie += "<td><img src="+imagen+" width='320' height='466'></td>\n"
                html_movie += "<td>\n"
                html_movie += "<div>Nombre: <br>-"+datos[1]+"</div>\n"
                html_movie += "<div>Director: <br>-"+datos[2]+"</div>\n"
                html_movie += "<div>Pais: <br>-"+datos[3]+"</div>\n"
                html_movie += "<div  id='actores'>Actores:<br>\n"
                for actor in conjuntoactores:
                    html_movie += "-"+actor+'<br>'
                html_movie+="</div>\n"

                html_movie += "</div>\n"
                html_movie += "</td>\n"
                html_movie += "</tr>\n"
                html_movie += "<tr>\n"

                html_movie += "</tr>\n"
                html_movie+="</table>\n"
                html_movie += " <iframe id=trailer  width='640' height='390' src=//www.youtube.com/embed/"+link+" frameborder='0' allowfullscreen>\n"
                html_movie += "</iframe>\n"
                html_movie+="<div><img src=/static/img/barra.png width='1000' height='20'></div>\n"
        a.close()
    if aux:
            redirect('/ups')









    archivo = open("static/login.html")
    html = archivo.read()
    html = html.replace("<!--MOVIE-->", html_movie)
    html=   html.replace("<!--PELICULAS-->", html_lista)

    return html

#Acciones de enlace
@route('/actorapelicula')
def actorapelicula():
    a=open('peliculas.dat')
    b=open('actores.dat')

    html_listapeliculas=''
    for linea in a:
        nombre=linea.strip().split(';')[1]
        idd=linea.strip().split(';')[0]
        html_listapeliculas+="<option value="+idd+">"+nombre+"</option>\n"
    a.close()

    html_listaactores=''
    for linea in b:
        nombre2=linea.strip().split(';')[1]
        idd2=linea.strip().split(';')[0]
        html_listaactores+="<option value="+idd2+">"+nombre2+"</option>\n"
    b.close()




    archivo = open("static/actorapelicula.html")
    html = archivo.read()
    html = html.replace("<!--PELICULAS-->", html_listapeliculas)
    html = html.replace("<!--ACTORES-->", html_listaactores)
    archivo.close()
    return html

@route('/accionagregarrelacion', method='POST')
def relacion():
    archivo = open("static/relacionexitosa.html")
    html = archivo.read()
    archivo.close()


    idactor= request.forms.get("listaactores")
    idpelicula = request.forms.get("listapeliculas")
    

    datos=dict()
    datos["idactor"]=idactor
    datos["idpelicula"]=idpelicula

    crear_relacion(datos)
    return html


@route('/ups')
def error_ups():
    archivo = open("static/login.html")
    html = archivo.read()
    html = html.replace("<!--UPS-->", "¡UPS!. Algo salió mal.")
    archivo.close()
    return html



# No borrar ni modificar
run(host='localhost', port=8080)

